// Luxury Arena private 1v1 server. No dependencies: just Node.js 16+.
// Run:  node server.js        (optional: TOKEN=secret PORT=8080 node server.js)
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = process.env.PORT || 8080, TOKEN = process.env.TOKEN || '';
const HTML = path.join(__dirname, 'public', 'index.html');
const rooms = new Map();

function frame(str) {
  const b = Buffer.from(str), n = b.length;
  let h;
  if (n < 126) h = Buffer.from([0x81, n]);
  else if (n < 65536) { h = Buffer.alloc(4); h[0] = 0x81; h[1] = 126; h.writeUInt16BE(n, 2); }
  else { h = Buffer.alloc(10); h[0] = 0x81; h[1] = 127; h.writeBigUInt64BE(BigInt(n), 2); }
  return Buffer.concat([h, b]);
}

const srv = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname === '/') {
    if (TOKEN && u.searchParams.get('k') !== TOKEN) { res.writeHead(403); return res.end('Forbidden'); }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return fs.createReadStream(HTML).pipe(res);
  }
  res.writeHead(404); res.end();
});

srv.on('upgrade', (req, sock) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname !== '/ws' || (TOKEN && u.searchParams.get('k') !== TOKEN) || !req.headers['sec-websocket-key']) { sock.destroy(); return; }
  const acc = crypto.createHash('sha1').update(req.headers['sec-websocket-key'] + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + acc + '\r\n\r\n');
  sock.setNoDelay(true);
  let room = null, buf = Buffer.alloc(0);
  const leave = () => { if (room) { room.delete(sock); if (!room.size) rooms.delete(room.n); room = null; } };
  const send = (s, o) => { if (!s.destroyed) s.write(frame(JSON.stringify(o))); };
  sock.on('data', d => {
    buf = Buffer.concat([buf, d]);
    for (;;) {
      if (buf.length < 2) return;
      const op = buf[0] & 15; let len = buf[1] & 127, off = 2;
      if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
      if (len > 16384 || !(buf[1] & 128)) { sock.destroy(); return; }
      if (buf.length < off + 4 + len) return;
      const mask = buf.slice(off, off + 4), p = Buffer.alloc(len);
      for (let i = 0; i < len; i++) p[i] = buf[off + 4 + i] ^ mask[i & 3];
      buf = buf.slice(off + 4 + len);
      if (op === 8) { sock.end(); return; }
      if (op === 9) { sock.write(Buffer.concat([Buffer.from([0x8a, Math.min(len, 125)]), p.slice(0, 125)])); continue; }
      if (op !== 1) continue;
      let m; try { m = JSON.parse(p.toString()); } catch (e) { continue; }
      if (m.j && !room) {
        const n = String(m.j).slice(0, 48); let r = rooms.get(n);
        if (!r) { r = new Set(); r.n = n; rooms.set(n, r); }
        if (r.size >= 2) { send(sock, { err: 'full' }); sock.end(); return; }
        r.add(sock); room = r; send(sock, { ok: 1 });
      } else if (m.e && room) {
        const o = JSON.stringify({ t: String(m.e).slice(0, 48), d: m.d });
        for (const s of room) if (s !== sock && !s.destroyed) s.write(frame(o));
      }
    }
  });
  sock.on('close', leave); sock.on('error', leave);
});

srv.listen(PORT, () => console.log('Luxury Arena server: http://localhost:' + PORT + (TOKEN ? '/?k=' + TOKEN : '')));
